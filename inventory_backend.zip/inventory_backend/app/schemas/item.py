from pydantic import BaseModel
from typing import Optional

class ItemBase(BaseModel):
    name: str
    sku: str
    category: str
    description: Optional[str] = None
    quantity: int

class ItemCreate(ItemBase):
    pass

class ItemUpdate(BaseModel):
    name: Optional[str]
    category: Optional[str]
    description: Optional[str]
    quantity: Optional[int]

class ItemOut(ItemBase):
    id: int

    class Config:
        orm_mode = True
