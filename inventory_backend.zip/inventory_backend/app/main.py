from fastapi import FastAPI
from app.database import engine
from app.models import item
from app.routers import item as item_router

item.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Inventory Management API",
    description="Manage products and stock levels",
    version="1.0.0"
)

app.include_router(item_router.router, prefix="/items", tags=["Items"])
